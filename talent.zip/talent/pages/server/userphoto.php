<?php
require_once './DBConnector.php';

use server\DbConnector;

$dbcon = new DbConnector();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['userID']) && !empty($_POST['userID']) && isset($_FILES["userprofile"]) && $_FILES["userprofile"]["error"] === 0) {
        // Sanitize user input to prevent SQL injection and XSS attacks
        $userID = htmlspecialchars($_POST['userID']);

        // Get the current image path if available
        $currentImagePath = isset($_POST['lodPic']) ? htmlspecialchars($_POST['lodPic']) : null;

        if (!empty($currentImagePath)) {
            unlink($currentImagePath); // Delete the file from the server
        }

        // File upload handling
        $targetDir = "../../upload/userprofile/";
        $imageFileName = $userID . "." . strtolower(pathinfo($_FILES["userprofile"]["name"], PATHINFO_EXTENSION));
        $targetFile = $targetDir . $imageFileName;

        $allowedExtensions = array("jpg", "jpeg", "png");
        if (in_array(strtolower(pathinfo($imageFileName, PATHINFO_EXTENSION)), $allowedExtensions)) {
            if (move_uploaded_file($_FILES["userprofile"]["tmp_name"], $targetFile)) {
                $imageFilePath = $targetFile;
            } else {
                // Redirect to the company profile page with error message for file upload failure
                header("Location: ../jobseeker/userProfile.php?error=3");
                exit();
            }
        } else {
            // Redirect to the company profile page with error message for invalid file type
            header("Location: ../jobseeker/userProfile.php?error=4");
            exit();
        }

        try {
            $con = $dbcon->getConnection();
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Update the company information in the database table using a prepared statement
            $sql = "UPDATE jobseeker SET profilePic=? WHERE userID=?";
            $pstmt = $con->prepare($sql);
            $pstmt->bindValue(1, $imageFilePath);
            $pstmt->bindValue(2, $userID);

            if ($pstmt->execute()) {
                // Redirect to the company profile page with success message
                header("Location: ../jobseeker/userProfile.php?success=1");
                exit();
            } else {
                echo "Error: Unable to update company information in the database.";
            }

            $con = null;
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    } else {
        // Return an error if the file is not selected
        header("Location: ../jobseeker/userProfile.php?error=5");
        exit();
    }
} else {
    // Redirect to the company profile page with error message for invalid request method
    header("Location: ../jobseeker/userProfile.php?error=1");
    exit();
}
?>